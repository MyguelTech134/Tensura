(() => {
  const build = document.querySelector('meta[name="slimebound-build"]').content;
  const badge = document.createElement("div");
  badge.id = "slimebound-offline-status";
  badge.setAttribute("role", "status");
  badge.setAttribute("aria-live", "polite");
  badge.style.cssText =
    "position:fixed;top:max(env(safe-area-inset-top),4px);left:50%;transform:translateX(-50%);" +
    "z-index:10000;max-width:85vw;padding:3px 10px;background:#142736ed;color:#edf7f7;" +
    "border-radius:10px;font:500 12px/1.5 system-ui,sans-serif;text-align:center;pointer-events:none";
  document.body.append(badge);
  let timer;
  let verified = false;

  function status(state, text, timeout) {
    clearTimeout(timer);
    badge.hidden = false;
    badge.dataset.status = state;
    badge.textContent = text;
    if (timeout) timer = setTimeout(() => { badge.hidden = true; }, timeout);
  }

  async function verify(worker) {
    if (!worker) return;
    const channel = new MessageChannel();
    const response = new Promise(resolve => {
      const timeout = setTimeout(() => {
        channel.port1.close();
        resolve(null);
      }, 8000);
      channel.port1.onmessage = event => {
        clearTimeout(timeout);
        channel.port1.close();
        resolve(event.data);
      };
    });
    worker.postMessage({type: "offline-status"}, [channel.port2]);
    const result = await response;
    if (result?.ready && result.build === build && worker === navigator.serviceWorker.controller) {
      verified = true;
      status("ready", "Offline bereit", 8000);
    }
  }

  function watch(worker) {
    if (!worker) return;
    worker.addEventListener("statechange", () => {
      if (worker.state === "redundant" && !verified && !navigator.serviceWorker.controller) {
        status("failed", "Offline-Download unvollständig. Online neu laden.");
      }
    });
  }

  async function start() {
    if (!window.isSecureContext || !("serviceWorker" in navigator)) {
      status("unavailable", "Offline-Installation benötigt HTTPS oder localhost.", 12000);
      return;
    }
    status("loading", "Offline-Paket wird geprüft …");
    const service = navigator.serviceWorker;
    service.addEventListener("controllerchange", () => verify(service.controller));
    await verify(service.controller);
    try {
      const registration = await service.register("./slimebound-sw.js", {scope: "./", updateViaCache: "none"});
      watch(registration.installing);
      registration.addEventListener("updatefound", () => watch(registration.installing));
      // On first installation clients.claim() signals controllerchange after verification.
      await service.ready;
      await verify(service.controller);
    } catch (error) {
      if (!verified) status("failed", "Offline-Installation ausstehend. Online neu laden.");
    }
  }
  start().catch(() => status("failed", "Offline-Installation ausstehend. Online neu laden."));
})();
