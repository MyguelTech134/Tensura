/* The packager injects a build ID and SHA-256 digests for every game asset. */
const pack = {"build":"1e0c9a7e4ff6c893537dce963ce9f247959b14322b01817744382e1fe13aef2d","assets":{"NOTICE.txt":"065a8216a1e6e6428028a5fe5a16a71188b38bfc3e941c33712c906ee353cf00","index.apple-touch-icon.png":"7e80117f3591dac4f20d780497f7eb299caf7ce3a195c7ed98fe5e05e5d85eac","index.audio.position.worklet.js":"be33985bc7160d6bf9646f259cd86b259cd67b02ccb297ee5c44f8ac84327bc8","index.audio.worklet.js":"5b476a9c9ce642c0ee4256436d1bc31d9c38f868aca0f9a8e2a57c18d2dec2a3","index.html":"7f12d7d49915809d7fc8c18a84575c6d5d2297bd449a2d87986541c338441163","index.icon.png":"05304bb6c7f18a324888a866cc44c72edc221aed48ddae014729c45566d7a7b6","index.js":"33c94cb3175f3333b82e2a3be5e8e86f77986f0aa2042b1631f6367a4e5bb6ba","index.pck":"e459c6c86b694667e468219f41d1959acf0f529047da4112191a2272ffdd29e9","index.png":"05304bb6c7f18a324888a866cc44c72edc221aed48ddae014729c45566d7a7b6","index.wasm":"fc74679e3b97f76878947fcd4fbe1268cbfa6188182a2e33bbc3f5dc9bfa57d0","slimebound-icon-180.png":"04e2bdf15d94233945238573c966f46a97942d480e78b5c0ba7700293f4d6187","slimebound-icon-192.png":"4170ebdc895f6ebc8ba963b8cffa9fe33641e9a7d2b5b44deaf1b467de850aec","slimebound-icon-512.png":"168f6b73af666f27ac0d5b6d8bb66cbb2a3ae8996e1cdf587c88272238efd5cd","slimebound-offline.js":"fdbe149092dd31cdb5dfd6f63ce51b0fa6848d55c02168673323e5828bad5a7c","slimebound.webmanifest":"a7c92a82114be3f540136684a97375994cdfc47edb3ee951f90f33e60375bf9b"}};
const scope = self.registration.scope;
const prefix = "slimebound-game:" + encodeURIComponent(scope) + ":";
const cacheName = prefix + pack.build;
const markerURL = new URL("./.slimebound-complete", scope).href;
const indexURL = new URL("index.html", scope).href;
const assetURLs = new Map(Object.entries(pack.assets).map(([path, hash]) => [new URL(path, scope).href, hash]));

function hex(bytes) {
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}

async function complete(cache) {
  if (!await cache.match(markerURL)) return false;
  const keys = new Set((await cache.keys()).map(request => request.url));
  return [...assetURLs.keys()].every(url => keys.has(url));
}

async function fetchVerified(url) {
  const response = await fetch(url, {cache: "no-store", credentials: "same-origin"});
  if (response.status !== 200 || response.redirected) throw new Error("Datei fehlt: " + url);
  const bytes = await response.arrayBuffer();
  if (hex(await crypto.subtle.digest("SHA-256", bytes)) !== assetURLs.get(url)) {
    throw new Error("Unvollständiger oder gemischter Export: " + url);
  }
  // fetch() already decodes HTTP transport compression. Store the decoded bytes.
  const headers = new Headers(response.headers);
  headers.delete("Content-Encoding");
  headers.delete("Vary");
  headers.set("Content-Length", String(bytes.byteLength));
  return new Response(bytes, {headers});
}

async function installPack(repair = false) {
  const cache = await caches.open(cacheName);
  if (await complete(cache)) return;
  try {
    // Process one asset at a time to bound peak memory on mobile devices.
    const known = repair ? new Set((await cache.keys()).map(key => key.url)) : new Set();
    for (const url of assetURLs.keys()) {
      if (!known.has(url)) await cache.put(url, await fetchVerified(url));
    }
    await cache.put(markerURL, new Response(pack.build));
    if (!await complete(cache)) throw new Error("Paketprüfung fehlgeschlagen");
  } catch (error) {
    if (!repair) await caches.delete(cacheName);
    throw error;
  }
}

let repair;
function repairPack() {
  if (!repair) repair = installPack(true).finally(() => { repair = null; });
  return repair;
}

self.addEventListener("install", event => {
  // An update waits for the previous version's open windows to close.
  event.waitUntil(installPack());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(cacheName);
    if (!await complete(cache)) throw new Error("Offlinepaket ist unvollständig");
    await self.clients.claim();
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    }
  })());
});

self.addEventListener("message", event => {
  if (event.data?.type !== "offline-status" || !event.ports[0]) return;
  event.waitUntil((async () => {
    let ready = await complete(await caches.open(cacheName));
    if (!ready) {
      try { await repairPack(); ready = true; } catch { /* A verified partial cache stays available. */ }
    }
    event.ports[0].postMessage({build: pack.build, ready});
  })());
});

async function rangeResponse(response, range) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match || (!match[1] && !match[2])) return response;
  const blob = await response.blob();
  const start = match[1] ? Number(match[1]) : Math.max(0, blob.size - Number(match[2]));
  const last = match[1] && match[2] ? Math.min(Number(match[2]), blob.size - 1) : blob.size - 1;
  if (start > last || start >= blob.size) {
    return new Response(null, {status: 416, headers: {"Content-Range": "bytes */" + blob.size}});
  }
  const headers = new Headers(response.headers);
  headers.set("Content-Length", String(last - start + 1));
  headers.set("Content-Range", "bytes " + start + "-" + last + "/" + blob.size);
  headers.set("Accept-Ranges", "bytes");
  return new Response(blob.slice(start, last + 1), {status: 206, headers});
}

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  url.search = "";
  url.hash = "";
  const asset = url.href === scope ? indexURL : url.href;
  if (!assetURLs.has(asset)) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    let response = await cache.match(asset);
    if (!response) {
      try {
        response = await fetchVerified(asset);
        await cache.put(asset, response.clone());
      } catch {
        return new Response("Offlinepaket fehlt. Zum erneuten Laden Internetverbindung herstellen.", {status: 503});
      }
    }
    const range = event.request.headers.get("Range");
    return range ? rangeResponse(response, range) : response;
  })());
});
